#!/bin/bash

# Planera Scheduling App - Docker Quick Start Script

echo "🚀 Starting Planera Scheduling App with Docker..."

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first:"
    echo "   https://docker.com/get-started/"
    exit 1
fi

# Check if Docker is running
if ! docker info &> /dev/null; then
    echo "❌ Docker is not running. Please start Docker first."
    exit 1
fi

echo "✅ Docker is installed and running"

# Pull the Node.js image if not already present
echo "📦 Pulling Node.js 22 Alpine image..."
docker pull node:22-alpine

# Build the application image
echo "🔨 Building Planera application..."
docker build -t planera-app .

# Run the container
echo "🎯 Starting the application..."
echo "   The app will be available at: http://localhost:3000"
echo "   Press Ctrl+C to stop the application"

docker run -p 3000:3000 planera-app


