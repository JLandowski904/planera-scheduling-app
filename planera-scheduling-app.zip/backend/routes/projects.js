import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { runQuery, getQuery, allQuery } from '../database.js';
import { verifyToken } from '../middleware/auth.js';

const router = express.Router();

// Get all projects for current user (owned + shared)
router.get('/', verifyToken, async (req, res) => {
  try {
    const { userId } = req.user;

    // Get owned projects
    const ownedProjects = await allQuery(
      `SELECT p.*, u.displayName as ownerName 
       FROM projects p 
       JOIN users u ON p.ownerId = u.id 
       WHERE p.ownerId = ? 
       ORDER BY p.updatedAt DESC`,
      [userId]
    );

    // Get shared projects
    const sharedProjects = await allQuery(
      `SELECT DISTINCT p.*, u.displayName as ownerName, pm.role
       FROM projects p 
       JOIN project_members pm ON p.id = pm.projectId 
       JOIN users u ON p.ownerId = u.id 
       WHERE pm.userId = ? 
       ORDER BY p.updatedAt DESC`,
      [userId]
    );

    // Combine and parse project data
    const allProjects = [...ownedProjects, ...sharedProjects].map(p => ({
      ...p,
      projectData: JSON.parse(p.projectData || '{}')
    }));

    res.json({ projects: allProjects });
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
});

// Get single project
router.get('/:projectId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.user;
    const { projectId } = req.params;

    const project = await getQuery('SELECT * FROM projects WHERE id = ?', [projectId]);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Check permissions
    const isMember = await getQuery(
      'SELECT id FROM project_members WHERE projectId = ? AND userId = ?',
      [projectId, userId]
    );

    if (project.ownerId !== userId && !isMember) {
      return res.status(403).json({ error: 'Access denied' });
    }

    project.projectData = JSON.parse(project.projectData || '{}');
    res.json({ project });
  } catch (error) {
    console.error('Get project error:', error);
    res.status(500).json({ error: 'Failed to fetch project' });
  }
});

// Create new project
router.post('/', verifyToken, async (req, res) => {
  try {
    const { userId } = req.user;
    const { name, description, projectData } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Project name is required' });
    }

    const projectId = uuidv4();
    const defaultProjectData = projectData || {
      nodes: [],
      edges: [],
      phases: [],
      viewSettings: {
        currentView: 'whiteboard',
        zoom: 1,
        pan: { x: 0, y: 0 },
        snapToGrid: true,
        gridSize: 20,
        showGrid: true,
      },
      filters: {
        types: [],
        statuses: [],
        assignees: [],
        disciplines: [],
        tags: [],
        phases: [],
        blockedOnly: false,
        customPresets: [],
      }
    };

    await runQuery(
      `INSERT INTO projects (id, name, description, ownerId, projectData) 
       VALUES (?, ?, ?, ?, ?)`,
      [projectId, name, description || '', userId, JSON.stringify(defaultProjectData)]
    );

    res.status(201).json({
      message: 'Project created successfully',
      project: {
        id: projectId,
        name,
        description: description || '',
        ownerId: userId,
        projectData: defaultProjectData,
        createdAt: new Date().toISOString()
      }
    });
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({ error: 'Failed to create project' });
  }
});

// Update project
router.put('/:projectId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.user;
    const { projectId } = req.params;
    const { name, description, projectData } = req.body;

    const project = await getQuery('SELECT * FROM projects WHERE id = ?', [projectId]);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    if (project.ownerId !== userId) {
      return res.status(403).json({ error: 'Only owner can update project' });
    }

    await runQuery(
      `UPDATE projects SET name = ?, description = ?, projectData = ?, updatedAt = CURRENT_TIMESTAMP 
       WHERE id = ?`,
      [name || project.name, description !== undefined ? description : project.description, 
       projectData ? JSON.stringify(projectData) : project.projectData, projectId]
    );

    res.json({ message: 'Project updated successfully' });
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({ error: 'Failed to update project' });
  }
});

// Delete project
router.delete('/:projectId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.user;
    const { projectId } = req.params;

    const project = await getQuery('SELECT * FROM projects WHERE id = ?', [projectId]);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    if (project.ownerId !== userId) {
      return res.status(403).json({ error: 'Only owner can delete project' });
    }

    await runQuery('DELETE FROM project_members WHERE projectId = ?', [projectId]);
    await runQuery('DELETE FROM project_activity WHERE projectId = ?', [projectId]);
    await runQuery('DELETE FROM projects WHERE id = ?', [projectId]);

    res.json({ message: 'Project deleted successfully' });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({ error: 'Failed to delete project' });
  }
});

// Share project with user
router.post('/:projectId/share', verifyToken, async (req, res) => {
  try {
    const { userId } = req.user;
    const { projectId } = req.params;
    const { userEmail, role } = req.body;

    // Check ownership
    const project = await getQuery('SELECT * FROM projects WHERE id = ?', [projectId]);
    if (!project || project.ownerId !== userId) {
      return res.status(403).json({ error: 'Only owner can share project' });
    }

    // Find user by email
    const shareWithUser = await getQuery('SELECT id FROM users WHERE email = ?', [userEmail]);
    if (!shareWithUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Add member
    const memberId = uuidv4();
    await runQuery(
      `INSERT OR IGNORE INTO project_members (id, projectId, userId, role) VALUES (?, ?, ?, ?)`,
      [memberId, projectId, shareWithUser.id, role || 'viewer']
    );

    res.json({ message: 'Project shared successfully' });
  } catch (error) {
    console.error('Share project error:', error);
    res.status(500).json({ error: 'Failed to share project' });
  }
});

// Get project members
router.get('/:projectId/members', verifyToken, async (req, res) => {
  try {
    const { userId } = req.user;
    const { projectId } = req.params;

    const project = await getQuery('SELECT * FROM projects WHERE id = ?', [projectId]);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const isMember = await getQuery(
      'SELECT id FROM project_members WHERE projectId = ? AND userId = ?',
      [projectId, userId]
    );

    if (project.ownerId !== userId && !isMember) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const members = await allQuery(
      `SELECT u.id, u.username, u.displayName, u.email, pm.role, pm.joinedAt
       FROM project_members pm
       JOIN users u ON pm.userId = u.id
       WHERE pm.projectId = ?`,
      [projectId]
    );

    res.json({ members });
  } catch (error) {
    console.error('Get members error:', error);
    res.status(500).json({ error: 'Failed to fetch members' });
  }
});

// Remove member from project
router.delete('/:projectId/members/:memberId', verifyToken, async (req, res) => {
  try {
    const { userId } = req.user;
    const { projectId, memberId } = req.params;

    const project = await getQuery('SELECT * FROM projects WHERE id = ?', [projectId]);
    if (!project || project.ownerId !== userId) {
      return res.status(403).json({ error: 'Only owner can remove members' });
    }

    await runQuery('DELETE FROM project_members WHERE projectId = ? AND userId = ?', [projectId, memberId]);
    res.json({ message: 'Member removed successfully' });
  } catch (error) {
    console.error('Remove member error:', error);
    res.status(500).json({ error: 'Failed to remove member' });
  }
});

export default router;


