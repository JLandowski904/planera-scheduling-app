# Schedule Planner API Backend

This is the backend API server for the Schedule Planner application. It provides user authentication, project management, and collaboration features.

## Prerequisites

- Node.js (v14 or higher)
- npm (comes with Node.js)

## Setup Instructions

### 1. Install Dependencies

```bash
cd backend
npm install
```

### 2. Create Environment File

Create a `.env` file in the `backend` folder with the following content:

```
PORT=5000
NODE_ENV=development
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
DATABASE_URL=./data/schedule.db
CORS_ORIGIN=http://localhost:3000
```

**Important:** Change the `JWT_SECRET` to a strong, random string for production use.

### 3. Start the Server

```bash
npm start
```

You should see:
```
Server running on http://localhost:5000
CORS enabled for: http://localhost:3000
Connected to SQLite database
Database schema initialized
```

## API Endpoints

### Authentication Routes (`/api/auth`)

- **POST** `/signup` - Create a new user account
  ```json
  {
    "email": "user@example.com",
    "username": "username",
    "password": "password",
    "displayName": "John Doe"
  }
  ```

- **POST** `/login` - Log in with email and password
  ```json
  {
    "email": "user@example.com",
    "password": "password"
  }
  ```

- **GET** `/me` - Get current authenticated user (requires auth token)

### Project Routes (`/api/projects`)

All project routes require an `Authorization: Bearer <token>` header.

- **GET** `/` - Get all projects (owned + shared)

- **GET** `/:projectId` - Get a specific project

- **POST** `/` - Create a new project
  ```json
  {
    "name": "Project Name",
    "description": "Optional description"
  }
  ```

- **PUT** `/:projectId` - Update project data

- **DELETE** `/:projectId` - Delete a project

- **POST** `/:projectId/share` - Share project with another user
  ```json
  {
    "userEmail": "colleague@example.com",
    "role": "viewer"
  }
  ```

- **GET** `/:projectId/members` - Get project members

- **DELETE** `/:projectId/members/:memberId` - Remove member from project

## Database

The backend uses SQLite for data storage. The database file is created automatically at `backend/data/schedule.db`.

### Database Tables

- **users** - User accounts and authentication
- **projects** - Project metadata and data
- **project_members** - Project collaboration and sharing
- **project_activity** - Activity log for auditing

## Features

✅ User authentication with JWT tokens  
✅ Secure password hashing with bcryptjs  
✅ Project CRUD operations  
✅ Project sharing and collaboration  
✅ Role-based access control (owner/viewer)  
✅ CORS enabled for frontend communication  
✅ SQLite database for persistent storage  

## Troubleshooting

### Port Already in Use
If port 5000 is already in use, change the `PORT` in your `.env` file.

### Database Issues
If you encounter database issues, delete the `backend/data/schedule.db` file and restart the server. A fresh database will be created.

### CORS Errors
Make sure the `CORS_ORIGIN` in your `.env` file matches your frontend URL (default is `http://localhost:3000`).

## Development

For development with automatic restart on file changes, you can use nodemon:

```bash
npm install -g nodemon
nodemon server.js
```

Or if nodemon is installed locally:

```bash
npx nodemon server.js
```


